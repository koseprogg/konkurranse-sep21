#
#   Gjett et tall!
#
#   I denne oppgaven skal du gjette på et tilfeldig tall, fra 1 til 10.
#
#   Tallet du gjetter skal gis som input, og så skal programmet fortelle deg
#   om det var riktig tall, eller feil tall.
#
#   For å gjøre det litt mer interessant, kan du også gjøre slik at programmet
#   forteller deg om du gjettet for høyt, eller for lavt.
#
#   For litt ekstra creds kan du også først fortelle programmet hva det høyeste
#   tallet man kan gjette på er!
#

import random

right_answer = random.randint(1, 10)

#
#   Din kode her!
#
