#
# I denne oppgaven har du fått en liste med tall.
#
# To av disse tallene blir til sammen 2021, og oppgaven din er å finne ut hvilke to!
#
# Bruk kode-skjellettet under, og endre koden slik at man får svaret når man kjører denne kodefilen.
#
# (Oppgaven er inspirert av dag 1 i Advent of Code 2020)
#

number_list = [
    1722,
    979,
    235,
    366,
    578,
    299,
    675,
    1245,
    744,
    1834,
    1456
]

goal = 2021
num_1 = 0
num_2 = 0

#
#   Gjør magien din her!
#

print([num_1, num_2])
