#
#   Sjekk om personen kan ta lappen!
#
#   I denne oppgaven skal du sjekke om en person
#   er gammel nok til å ta sertifikatet for bil i landet sitt.
#
#   Funksjonen under skal ta inn to parametre: alder og land.
#
#   Om personen er fra Norge, må hen være 18 år eller eldre for å ta lappen.
#   Om personen er fra USA, mer aldersgrensen 16 år.
#
#   Dette betyr at
#
#       age = 17
#       country = "Norway"
#
#   skal printe noe sånt som
#
#       "The person is not old enough to drive ⛔",
#
#   og at
#
#       age = 17
#       country = "USA"
#
#   skal printe noe sånt som
#
#       "The person is old enough to drive 🚗"
#
#
#   Bruk kodeskjelettet under til å fullføre funksjonen!
#

age = None  # Noe input (hint: Husk å konvertere til tall med int() )
country = None  # Noe input

#
#   Skriv koden din her!
#


print("The person is not old enough to drive ⛔")

